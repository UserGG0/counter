# Animated Number Counter with Vanilla JavaScript

A Pen created on CodePen.io. Original URL: [https://codepen.io/akhijannat/pen/JjYQgNK](https://codepen.io/akhijannat/pen/JjYQgNK).

